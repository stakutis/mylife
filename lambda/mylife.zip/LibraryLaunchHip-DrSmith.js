module.exports={
    launchMessage: "Dr. Smith is interested in your hip progress. , "
}


